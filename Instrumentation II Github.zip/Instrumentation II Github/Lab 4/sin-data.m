# Created by Octave 4.0.0, Mon Feb 01 15:24:28 2016 NPT <sujit@sujit-pc>
# name: data
# type: matrix
# rows: 1
# columns: 25
 128 160 191 218 238 251 255 251 238 218 191 160 128 95 64 37 17 4 0 4 17 37 64 95 127


